import RPi.GPIO as GPIO
import time
import statistics

class UltrasonicSensor:
    def __init__(self, trigger_pin, echo_pin):
        self.GPIO_TRIGGER = trigger_pin
        self.GPIO_ECHO = echo_pin

        # Setup GPIO pins
        GPIO.setmode(GPIO.BCM)
        GPIO.setup(self.GPIO_TRIGGER, GPIO.OUT)
        GPIO.setwarnings(False)
        GPIO.setup(self.GPIO_ECHO, GPIO.IN)
        GPIO.output(self.GPIO_TRIGGER, False)
        time.sleep(2)  # Allow sensor to settle

    def read_distance(self):
        try:
            speedSound = 34300  # Speed of sound in cm/s at room temperature

            # Trigger the sensor
            GPIO.output(self.GPIO_TRIGGER, True)
            time.sleep(0.00001)
            GPIO.output(self.GPIO_TRIGGER, False)

            start = time.time()
            stop = time.time()

            # Wait for the echo to start
            while GPIO.input(self.GPIO_ECHO) == 0:
                start = time.time()
                if time.time() - start > 0.03:  # Timeout to prevent infinite loop
                    raise RuntimeError("Ultrasonic sensor read timeout (start)")

            # Wait for the echo to stop
            while GPIO.input(self.GPIO_ECHO) == 1:
                stop = time.time()
                if time.time() - start > 0.03:  # Timeout to prevent infinite loop
                    raise RuntimeError("Ultrasonic sensor read timeout (stop)")

            elapsed = stop - start
            distance = (elapsed * speedSound) / 2  # Divide by 2 to account for the return trip
            return distance

        except RuntimeError as e:
            print(e)
            return None  # Return None on error

    def read(self, num_samples=3):
        distances = []

        for _ in range(num_samples):
            distance = self.read_distance()
            if distance is not None:
                distances.append(distance)
            time.sleep(0.02)  # Short delay between samples

        if len(distances) == 0:
            return None

        median_distance = statistics.median(distances)

        # Filter out readings that are too far from the median
        filtered_distances = [d for d in distances if abs(d - median_distance) < median_distance * 0.1]

        if len(filtered_distances) == 0:
            return None

        average_distance = sum(filtered_distances) / len(filtered_distances)
        return average_distance

    def cleanup(self):
        GPIO.cleanup()

# Usage example if this script is run directly
if __name__ == "__main__":
    try:
        sensor = UltrasonicSensor(trigger_pin=4, echo_pin=17)
        while True:
            distance = sensor.read()
            if distance is not None:
                print("Distance:", distance, "cm")
            else:
                print("Failed to read distance")
            time.sleep(0.2)  # Reduce the delay between reads to 0.2 seconds
    except KeyboardInterrupt:
        sensor.cleanup()
