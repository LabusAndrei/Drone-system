import multiprocessing as mp
import time
import atexit
import signal
import math
from gpiozero import DistanceSensor
from MPU6050 import MPU6050
from BMP280 import BMP280, BMP280Calibrator
from Ibus import RadioController
from Ultrasonic import UltrasonicSensor

def read_ultrasonic(queue, barrier):
    sensor = UltrasonicSensor(trigger_pin=20, echo_pin=16)
    
    barrier.wait()  # Așteaptă calibrarea

    while True:
        distance = sensor.read()
        queue.put(('ultrasonic', distance))
        time.sleep(0.3)  # Reduce delay for faster reads

def read_imu_and_bmp(queue, barrier):
    mpu = MPU6050()
    bmp280 = BMP280()
    calibrator = BMP280Calibrator(bmp280)
    baseline_altitude = calibrator.calculate_altitude_offset()
    z_velocity = 0

    barrier.wait()  # Așteaptă calibrarea

    while True:
        pitch, roll, acc_x, acc_y, acc_z = mpu.get_pitch_roll()
        z_velocity = mpu.vertical_velocity(pitch, roll, acc_x, acc_y, acc_z, z_velocity, mpu.dt)
        altitude = bmp280.read_sensor_data()
        altitude -= baseline_altitude
        altitude = max(altitude, 0)
        queue.put(('imu_bmp', (pitch, roll, z_velocity, altitude)))
        time.sleep(0.3)  # Reduce delay for faster reads

def read_radio(queue, barrier):
    radio = RadioController()

    barrier.wait()  # Așteaptă calibrarea

    while True:
        radio.read_data()
        reference_altitude = radio.get_reference_altitude()
        ch1, ch2, ch3, ch4, ch5, ch6 = radio.get_channels_data()
        queue.put(('radio', (reference_altitude, ch1, ch2, ch3, ch4, ch5, ch6)))
        time.sleep(0.01)  # Reduce delay to read faster

class PID:
    def __init__(self, kp, ki, kd, setpoint=0):
        self.kp = kp
        self.ki = ki
        self.kd = kd
        self.setpoint = setpoint
        self.previous_error = 0
        self.integral = 0

    def update(self, current_value, dt):
        error = self.setpoint - current_value
        self.integral += error * dt
        derivative = (error - self.previous_error) / dt
        output = self.kp * error + self.ki * self.integral + self.kd * derivative
        self.previous_error = error
        return output

def process_data(queue, barrier):
    LastTime = time.time()
    data_dict = {
        'ultrasonic': None,
        'imu_bmp': None,
        'radio': None
    }
    # Inițializăm PID-ul
    pid = PID(kp=4, ki=0.01, kd=2, setpoint=0)  # Valori de exemplu pentru kp, ki, kd
    barrier.wait()  # Așteaptă calibrarea

    while True:
        dateDateTimeNow = time.time()
        Time = dateDateTimeNow - LastTime
        
        try:
            sensor_type, data = queue.get(timeout=0.01)  # Non-blocking get with timeout
            data_dict[sensor_type] = data
        except mp.queues.Empty:
            continue

        if all(value is not None for value in data_dict.values()):
            distance = data_dict['ultrasonic']
            pitch, roll, z_velocity, altitude = data_dict['imu_bmp']
            reference_altitude, ch1, ch2, ch3, ch4, ch5, ch6 = data_dict['radio']
            
            # Convertim altitudinea în cm
            altitude_cm = altitude * 100
            
            # Calculăm altitudinea pe baza unghiurilor și distanței măsurate de ultrasonic
            if abs(roll) > 20 or abs(pitch) > 20:
                # Calculăm distanța verticală folosind trigonometria
                roll_rad = math.radians(roll)
                pitch_rad = math.radians(pitch)
                vertical_distance = distance * math.cos(roll_rad) * math.cos(pitch_rad)
            else:
                vertical_distance = distance

            # Verificăm dacă distanța măsurată de ultrasonic este mai mare sau egală cu 4 metri
            if distance >= 400:
                final_altitude = altitude_cm
            else:
                final_altitude = vertical_distance

            # Actualizăm PID-ul cu noul feedback
            pid.setpoint = reference_altitude
            pid_output = pid.update(final_altitude, Time)
            
            ch3= ch3 * 10 + 1000 + pid_output*10
            ch3 = max(1000, min(2000, ch3))

            #print(f"Time: {Time:.5f}, Pitch: {pitch:.2f}, Roll: {roll:.2f}, Z Velocity: {z_velocity:.2f}, Altitude: {final_altitude:.2f} cm, Distance: {distance:.2f} cm")
            #print("Channels: ch1={}, ch2={}, ch3={}, ch4={}, ch5={}, ch6={}".format(ch1, ch2, ch3, ch4, ch5, ch6))
            print(f"Reference_altitude:, {reference_altitude:.2f}, Altitude: {final_altitude:.2f}, PID: {pid_output}, Ch3: {ch3}")
        
        LastTime = dateDateTimeNow

if __name__ == "__main__":
    queue = mp.Queue()
    barrier = mp.Barrier(4)  # Bariera pentru sincronizare

    processes = [
        mp.Process(target=read_ultrasonic, args=(queue, barrier)),
        mp.Process(target=read_imu_and_bmp, args=(queue, barrier)),
        mp.Process(target=read_radio, args=(queue, barrier)),
        mp.Process(target=process_data, args=(queue, barrier))
    ]

    for p in processes:
        p.start()

    for p in processes:
        p.join()
