import serial
import time
import logging

# Configurare logging
logging.basicConfig(level=logging.DEBUG, format='%(asctime)s - %(levelname)s - %(message)s')

class RadioController:
    def __init__(self, serial_port="/dev/serial0", baudrate=115200):
        self.ser = serial.Serial(serial_port, baudrate)
        self.ser.parity = serial.PARITY_NONE
        self.ser.stopbits = serial.STOPBITS_ONE
        self.Reference_altitude = 0
        self.ch1, self.ch2, self.ch3, self.ch4, self.ch5, self.ch6 = 0, 0, 0, 0, 0, 0

    def read_data(self):
        try:
            frame = bytearray()
            while self.ser.in_waiting > 0:
                received_data = self.ser.read()
                frame.extend(received_data)

            if len(frame) >= 32 and frame[0] == 32:
                self.ch1, self.ch2, self.ch3, self.ch4, self.ch5, self.ch6 = self._process_frame(frame)

            self._update_reference_altitude()

        except Exception as e:
            logging.error(f"Error in read_data: {e}")

    def _process_frame(self, frame):
        ch1 = int.from_bytes(frame[2:4], byteorder='little')
        ch2 = int.from_bytes(frame[4:6], byteorder='little')
        ch3 = int.from_bytes(frame[6:8], byteorder='little')
        ch4 = int.from_bytes(frame[8:10], byteorder='little')
        ch5 = int.from_bytes(frame[10:12], byteorder='little')
        ch6 = int.from_bytes(frame[12:14], byteorder='little')
        
        ch3 = (ch3 - 1000) / 10  # Ajustează ch3 conform aplicației tale
        
        return ch1, ch2, ch3, ch4, ch5, ch6

    def _update_reference_altitude(self):
        if self.ch3 < 10:
            self.Reference_altitude = max(0, self.Reference_altitude - 5)
        elif 10 < self.ch3 < 20:
            self.Reference_altitude = max(0, self.Reference_altitude - 0.5)
        elif 20 < self.ch3 < 40:
            self.Reference_altitude = max(0, self.Reference_altitude - 0.05)
        elif 60 < self.ch3 < 80:
            self.Reference_altitude += 0.05
        elif 80 < self.ch3 < 90:
            self.Reference_altitude += 0.5
        elif self.ch3 >= 90:
            self.Reference_altitude += 5

    def get_reference_altitude(self):
        return self.Reference_altitude

    def get_channels_data(self):
        return self.ch1, self.ch2, self.ch3, self.ch4, self.ch5, self.ch6

    def cleanup(self):
        self.ser.close()

if __name__ == "__main__":
    try:
        radio = RadioController()
        while True:
            radio.read_data()
            reference_altitude = radio.get_reference_altitude()
            ch1, ch2, ch3, ch4, ch5, ch6 = radio.get_channels_data()
            logging.debug(f"Channels: ch1={ch1}, ch2={ch2}, ch3={ch3}, ch4={ch4}, ch5={ch5}, ch6={ch6}")
            logging.debug(f"Reference Altitude: {reference_altitude}")
            time.sleep(0.01)  # Pauză mică pentru a nu supraîncărca procesorul
    except KeyboardInterrupt:
        radio.cleanup()
        logging.info("Exiting...")
    except Exception as e:
        logging.error(f"Unhandled exception: {e}")
        radio.cleanup()
